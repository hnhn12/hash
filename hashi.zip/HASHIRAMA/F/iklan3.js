const iklan3 = () => {
	return`[ MASUKIN IKLAN KALIAN ]`
}

exports.iklan3 = iklan3